This directory is used by SoftConsole programming.  

It will contain the hexfile output from the HSS build.
