#!/bin/sh

export BOOTMODE=1
export PACKAGE=FCVG484
export DIE=MPFS250T_ES
export FPGENPROG=/usr/local/microsemi/Libero_SoC_v2021.1/Libero/bin64/fpgenprog
export SC_INSTALL_DIR=/home/daire/Microchip/SoftConsole-v2021.1
export BINDIR=Default

rm -rf ${BINDIR}/bootmode1
[ "${SC_INSTALL_DIR}" ] || ( echo "SC_INSTALL_DIR environment variable is unset"; exit 1 )
[ -d ${SC_INSTALL_DIR} ] || ( echo "SoftConsole subdirectory >>${SC_INSTALL_DIR}<< does not exist."; exit 2 )

${SC_INSTALL_DIR}/eclipse/jre/bin/java -jar ${SC_INSTALL_DIR}/extras/mpfs/mpfsBootmodeProgrammer.jar --workdir `pwd`/Default --die ${DIE} --package ${PACKAGE} --bootmode ${BOOTMODE}
